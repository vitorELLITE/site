const pool = require('./db');

async function criarTabela() {
    try {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS vagas (
                id SERIAL PRIMARY KEY,
                titulo VARCHAR(255) NOT NULL,
                local VARCHAR(255) NOT NULL,
                imagem_url TEXT,
                descricao TEXT,
                data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);
        console.log("✅ TABELA CRIADA COM SUCESSO NO LUGAR CERTO!");
    } catch (erro) {
        console.log("❌ Deu erro: ", erro.message);
    } finally {
        pool.end(); // Fecha a conexão
    }
}

criarTabela();