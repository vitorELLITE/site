require('dotenv').config();
const express = require('express');
const path = require('path');
const multer = require('multer');
const pool = require('./db'); // Conexão com o seu banco PostgreSQL

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'))); 

// --- CONFIGURAÇÃO DO MULTER ---
const storageGeral = multer.diskStorage({
    destination: 'public/uploads/',
    filename: (req, file, cb) => {
        const prefixo = file.fieldname === 'curriculo' ? 'CV_' : 'TI_';
        cb(null, prefixo + Date.now() + path.extname(file.originalname));
    }
});
const uploadGeral = multer({ storage: storageGeral });

const storageLoja = multer.diskStorage({
    destination: 'public/uploads/',
    filename: (req, file, cb) => cb(null, 'LOJA_' + file.fieldname + '_' + Date.now() + path.extname(file.originalname))
});
const uploadLoja = multer({ storage: storageLoja });


// =========================================================
// ROTAS DE ACESSO E LOGIN (NOVO!)
// =========================================================
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'login.html'));
});


// =========================================================
// ROTAS DO RH (ADMINISTRATIVO)
// =========================================================
const rhRoutes = require('./routes/rh');
app.use('/rh', rhRoutes); 


// =========================================================
// ROTAS DO SUPORTE T.I
// =========================================================
app.get('/suporte', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'suporte.html'));
});

app.post('/suporte/enviar', uploadGeral.single('anexo'), (req, res) => {
    console.log("Recebido chamado de T.I de:", req.body.usuario);
    res.send(`<h1 style="color:green; text-align:center; margin-top:50px;">Chamado T.I enviado! Feche a aba.</h1>`);
});


// =========================================================
// ROTAS DA LOJA (Fechamento)
// =========================================================
app.get('/loja', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'loja.html'));
});

app.post('/loja/enviar', uploadLoja.fields([{ name: 'file023b' }, { name: 'file020' }, { name: 'file021' }, { name: 'fileSitef' }]), (req, res) => {
    const { colaborador, data, tem_dinheiro } = req.body;
    console.log(`\n💰 NOVO FECHAMENTO DE CAIXA: ${colaborador} - ${data}`);
    res.send(`<h1 style="color:green; text-align:center; margin-top:50px;">Fechamento enviado ao Financeiro! Feche a aba.</h1>`);
});


// =========================================================
// ROTAS DO FINANCEIRO
// =========================================================
app.get('/financeiro', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'financeiro.html'));
});


// =========================================================
// ROTAS DE CARREIRAS (VAGAS E BANCO DE TALENTOS)
// =========================================================
app.get('/vagas', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'vagas.html'));
});

app.get('/candidatar', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'candidatura.html'));
});

app.post('/candidatar/enviar', uploadGeral.single('curriculo'), (req, res) => {
    const { nome, vaga_nome } = req.body;
    console.log(`✅ NOVA CANDIDATURA: ${nome} para ${vaga_nome}`);
    res.send("<script>alert('Candidatura enviada com sucesso!'); window.close();</script>");
});

app.post('/vagas/banco/enviar', uploadGeral.single('curriculo'), (req, res) => {
    res.send(`
        <div style="font-family: sans-serif; text-align: center; margin-top: 100px;">
            <h1 style="color: #6A3079;">Currículo Recebido!</h1>
            <p>Seu currículo foi salvo em nosso Banco de Talentos.</p>
            <br>
            <a href="/vagas" style="color: #6A3079; font-weight: bold;">Voltar para Vagas</a>
        </div>
    `);
});


// =========================================================
// ROTA PRINCIPAL E SERVIDOR
// =========================================================
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'home.html')); 
});

app.listen(3001, () => {
    console.log("🚀 Sistema Ellite Rodando: http://localhost:3001");
});