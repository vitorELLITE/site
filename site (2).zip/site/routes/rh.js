const express = require('express');
const router = express.Router();
const path = require('path');
const pool = require('../db');
const multer = require('multer');

const storage = multer.diskStorage({
    destination: 'public/uploads/',
    filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});
const upload = multer({ storage });

// 1. Mostrar a tela
router.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../views/rh.html'));
});

// 2. API para buscar as vagas cadastradas
router.get('/vagas', async (req, res) => {
    try {
        const resultado = await pool.query('SELECT * FROM vagas ORDER BY data_criacao DESC');
        res.json(resultado.rows);
    } catch (e) {
        res.status(500).json({ erro: e.message });
    }
});

// 3. Salvar nova vaga
router.post('/salvar', upload.single('imagem'), async (req, res) => {
    try {
        const { titulo, local, descricao } = req.body;
        const imagem = req.file ? `/uploads/${req.file.filename}` : '';
        
        await pool.query(
            "INSERT INTO vagas (titulo, local, imagem_url, descricao) VALUES ($1, $2, $3, $4)",
            [titulo, local, imagem, descricao]
        );
        res.redirect('/rh'); 
    } catch (e) {
        res.send("Erro: " + e.message);
    }
});

// 4. Excluir vaga
router.post('/excluir', async (req, res) => {
    try {
        const { id } = req.body;
        await pool.query('DELETE FROM vagas WHERE id = $1', [id]);
        res.redirect('/rh'); 
    } catch (e) {
        res.send("Erro ao excluir: " + e.message);
    }
});

// 5. API para buscar APENAS os candidatos NOVOS (Pendentes)
router.get('/candidatos', async (req, res) => {
    try {
        const resultado = await pool.query(`
            SELECT c.*, v.titulo as vaga_titulo 
            FROM candidatos c 
            LEFT JOIN vagas v ON c.vaga_id = v.id 
            WHERE c.status = 'pendente' OR c.status IS NULL
            ORDER BY c.data_inscricao DESC
        `);
        res.json(resultado.rows);
    } catch (e) {
        res.status(500).json({ erro: e.message });
    }
});

// 6. Atualizar status do candidato (Aprovar, Reprovar, Banco)
router.post('/candidatos/status', async (req, res) => {
    try {
        const { id, status } = req.body;
        await pool.query('UPDATE candidatos SET status = $1 WHERE id = $2', [status, id]);
        res.redirect('/rh');
    } catch (e) {
        res.send("Erro ao atualizar status: " + e.message);
    }
});

// 7. API para buscar o BANCO DE TALENTOS
router.get('/banco-talentos', async (req, res) => {
    try {
        const resultado = await pool.query(`
            SELECT c.*, v.titulo as vaga_titulo 
            FROM candidatos c 
            LEFT JOIN vagas v ON c.vaga_id = v.id 
            WHERE c.status = 'banco_talentos'
            ORDER BY c.data_inscricao DESC
        `);
        res.json(resultado.rows);
    } catch (e) {
        res.status(500).json({ erro: e.message });
    }
});

// 8. API para buscar os Chamados do DP
router.get('/chamados-dp', async (req, res) => {
    try {
        // Busca chamados onde o departamento destino é 'DP'
        const resultado = await pool.query(`SELECT * FROM chamados WHERE departamento = 'DP' ORDER BY data_criacao DESC`);
        res.json(resultado.rows);
    } catch (e) {
        res.status(500).json({ erro: e.message });
    }
});

// 9. API para buscar os Chamados do RH
router.get('/chamados-rh', async (req, res) => {
    try {
        // Busca chamados onde o departamento destino é 'RH'
        const resultado = await pool.query(`SELECT * FROM chamados WHERE departamento = 'RH' ORDER BY data_criacao DESC`);
        res.json(resultado.rows);
    } catch (e) {
        res.status(500).json({ erro: e.message });
    }
});

module.exports = router;